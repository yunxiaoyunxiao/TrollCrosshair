# FloatImage 1.1 — TrollStore iPadOS 原型

本版本基于 TrollCrosshair 仓库中的 FloatImage 1.0 工程更新，目标环境为 iPadOS 17.0 + TrollStore。

## 本次实现
- PHPicker 选择图片；优先保留原始文件，不再一律转成 PNG。
- GIF 使用 ImageIO 读取多帧，并构建 UIKit animated UIImage。
- 预览与悬浮层共用同一套图片解码方法。
- 修正设置页预览：使用独立预览画布，不再直接改变布局约束中的预览控件 bounds。
- 悬浮位置以窗口 safe area 中心为参考，考虑状态栏/安全区域。
- 保留 X、Y、宽度、高度、透明度五项参数与一键重置。
- 添加 URL Scheme：`floatimage://toggle`、`floatimage://show`、`floatimage://hide`，可由快捷指令的“打开 URL”动作调用。

## 重要限制
当前 FloatingController 仍然创建普通 UIKit UIWindow。`UIWindowLevelAlert + 1` 只影响当前应用的窗口排序，不能据此认定它可以覆盖其他 App。

URL Scheme 也可能使 iOS 将 FloatImage 带到前台；它不等于后台静默执行，也不等于已经实现跨 App 悬浮开关。

GGBall 3.5 的 IPA 逆向分析显示，它的签名包含特殊 FrontBoard / RunningBoard / SpringBoard 相关权限，并有同一可执行文件启动 `LauncherHUD` 模式的设计线索。普通 TrollStore App 并不会因为复制 `posix_spawn` 和高 windowLevel 就自动获得同等能力。下一阶段需要把 GGBall 的实际 scene/window 托管流程与 FloatImage 的签名权限、进程启动环境逐项对照，再实现独立 HUD 进程。

## 构建
在 macOS 上使用 Xcode 打开 `TrollCrosshair_1_0/TrollCrosshair.xcodeproj`，选择 FloatImage scheme，部署目标 iOS 17.0。当前对话环境无法运行 Xcode / iOS SDK，因此本包是源码更新，不宣称已完成编译或真机验证。

#import "FloatingController.h"
#import "FISettings.h"
#import <ImageIO/ImageIO.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>

@interface FIPassthroughWindow : UIWindow
@end
@implementation FIPassthroughWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event { return nil; }
@end

@interface FloatingController ()
@property(nonatomic,strong) UIWindow *overlayWindow;
@property(nonatomic,strong) UIImageView *imageView;
@property(nonatomic,strong) NSURL *imageURL;
@end

@implementation FloatingController

+ (instancetype)shared {
    static FloatingController *c; static dispatch_once_t once;
    dispatch_once(&once, ^{ c = [FloatingController new]; });
    return c;
}

// ImageIO keeps GIF decoding native and avoids losing the animation by first
// asking NSItemProvider to vend a UIImage.
+ (UIImage *)imageForURL:(NSURL *)url {
    if (!url) return nil;
    NSData *data = [NSData dataWithContentsOfURL:url options:NSDataReadingMappedIfSafe error:nil];
    if (!data) return nil;
    CGImageSourceRef source = CGImageSourceCreateWithData((__bridge CFDataRef)data, NULL);
    if (!source) return [UIImage imageWithData:data];

    size_t count = CGImageSourceGetCount(source);
    if (count <= 1) {
        CGImageRef cg = CGImageSourceCreateImageAtIndex(source, 0, NULL);
        UIImage *image = cg ? [UIImage imageWithCGImage:cg scale:UIScreen.mainScreen.scale orientation:UIImageOrientationUp] : [UIImage imageWithData:data];
        if (cg) CGImageRelease(cg);
        CFRelease(source);
        return image;
    }

    NSMutableArray<UIImage *> *frames = [NSMutableArray arrayWithCapacity:count];
    NSTimeInterval totalDuration = 0;
    for (size_t i = 0; i < count; i++) {
        CGImageRef cg = CGImageSourceCreateImageAtIndex(source, i, NULL);
        if (!cg) continue;
        UIImage *frame = [UIImage imageWithCGImage:cg scale:UIScreen.mainScreen.scale orientation:UIImageOrientationUp];
        [frames addObject:frame];
        CGImageRelease(cg);

        NSDictionary *properties = CFBridgingRelease(CGImageSourceCopyPropertiesAtIndex(source, i, NULL));
        NSDictionary *gif = properties[(NSString *)kCGImagePropertyGIFDictionary];
        NSNumber *delay = gif[(NSString *)kCGImagePropertyGIFUnclampedDelayTime];
        if (![delay isKindOfClass:NSNumber.class] || delay.doubleValue <= 0) delay = gif[(NSString *)kCGImagePropertyGIFDelayTime];
        NSTimeInterval frameDelay = delay.doubleValue;
        if (!isfinite(frameDelay) || frameDelay < 0.02) frameDelay = 0.1;
        totalDuration += frameDelay;
    }
    CFRelease(source);
    if (frames.count == 0) return [UIImage imageWithData:data];
    if (frames.count == 1) return frames.firstObject;
    // UIKit's animated UIImage uses a uniform frame cadence. Use the GIF's
    // accumulated duration so common GIFs retain approximately their speed.
    if (totalDuration <= 0) totalDuration = frames.count * 0.1;
    return [UIImage animatedImageWithImages:frames duration:totalDuration];
}

- (void)showImageAtURL:(NSURL *)url {
    self.imageURL = url;
    UIImage *image = [FloatingController imageForURL:url];
    if (!image) return;
    if (!self.overlayWindow) {
        UIWindowScene *scene = nil;
        for (UIScene *s in UIApplication.sharedApplication.connectedScenes) {
            if (s.activationState == UISceneActivationStateForegroundActive && [s isKindOfClass:UIWindowScene.class]) { scene = (UIWindowScene *)s; break; }
        }
        if (!scene) return;
        self.overlayWindow = [[FIPassthroughWindow alloc] initWithWindowScene:scene];
        self.overlayWindow.frame = scene.coordinateSpace.bounds;
        self.overlayWindow.windowLevel = UIWindowLevelAlert + 1;
        self.overlayWindow.backgroundColor = UIColor.clearColor;
        self.overlayWindow.opaque = NO;
        UIViewController *root = [UIViewController new];
        root.view.backgroundColor = UIColor.clearColor;
        self.overlayWindow.rootViewController = root;
        self.imageView = [UIImageView new];
        self.imageView.contentMode = UIViewContentModeScaleToFill;
        self.imageView.userInteractionEnabled = NO;
        self.imageView.backgroundColor = UIColor.clearColor;
        [root.view addSubview:self.imageView];
    }
    self.imageView.image = image;
    [self refresh];
    if (FISettings.shared.isEnabled) [self.overlayWindow makeKeyAndVisible];
    else self.overlayWindow.hidden = YES;
}

- (void)refresh {
    if (!self.overlayWindow || !self.imageView) return;
    FISettings *s = FISettings.shared;
    UIEdgeInsets safe = self.overlayWindow.safeAreaInsets;
    CGRect b = self.overlayWindow.bounds;
    CGFloat safeMinX = CGRectGetMinX(b) + safe.left;
    CGFloat safeMaxX = CGRectGetMaxX(b) - safe.right;
    CGFloat safeMinY = CGRectGetMinY(b) + safe.top;
    CGFloat safeMaxY = CGRectGetMaxY(b) - safe.bottom;
    CGFloat cx = (safeMinX + safeMaxX) * 0.5 + s.x;
    CGFloat cy = (safeMinY + safeMaxY) * 0.5 + s.y;
    self.imageView.bounds = CGRectMake(0, 0, MAX(1, s.width), MAX(1, s.height));
    self.imageView.center = CGPointMake(cx, cy);
    self.imageView.alpha = MIN(1, MAX(0, s.alpha));
}

- (void)setEnabled:(BOOL)enabled {
    FISettings.shared.enabled = enabled;
    [FISettings.shared save];
    if (enabled && self.imageURL) [self showImageAtURL:self.imageURL];
    self.overlayWindow.hidden = !enabled;
}
@end

#import "RootViewController.h"
#import <PhotosUI/PhotosUI.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#import "FISettings.h"
#import "FloatingController.h"

@interface RootViewController () <PHPickerViewControllerDelegate>
@property(nonatomic,strong) UIImageView *previewImageView;
@property(nonatomic,strong) UIView *previewCanvas;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic,strong) UIButton *toggleButton;
@property(nonatomic,strong) NSURL *imageURL;
@property(nonatomic,strong) NSMutableArray<UISlider *> *sliders;
@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    self.sliders = [NSMutableArray array];
    [self buildUI];
    [self loadSavedImage];
    [self syncControls];
}

- (UILabel *)label:(NSString *)text {
    UILabel *l = [UILabel new];
    l.text = text;
    l.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    return l;
}

- (UIButton *)button:(NSString *)title action:(SEL)action {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    [b setTitle:title forState:UIControlStateNormal];
    [b addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return b;
}

- (void)buildUI {
    UIScrollView *scroll = [UIScrollView new];
    scroll.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:scroll];
    [NSLayoutConstraint activateConstraints:@[
        [scroll.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:8],
        [scroll.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
        [scroll.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:18],
        [scroll.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor]
    ]];

    UIStackView *stack = [[UIStackView alloc] init];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 12;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [scroll addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor],
        [stack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor constant:-20],
        [stack.leadingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.leadingAnchor],
        [stack.trailingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.trailingAnchor],
        [stack.widthAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.widthAnchor]
    ]];

    UILabel *title = [self label:@"FloatImage 1.1"];
    title.font = [UIFont systemFontOfSize:26 weight:UIFontWeightBold];
    [stack addArrangedSubview:title];
    self.status = [self label:@"尚未选择图片"];
    self.status.numberOfLines = 0;
    [stack addArrangedSubview:self.status];
    [stack addArrangedSubview:[self button:@"选择图片 / GIF" action:@selector(pickImage)]];

    self.previewCanvas = [UIView new];
    self.previewCanvas.backgroundColor = UIColor.secondarySystemBackgroundColor;
    self.previewCanvas.layer.cornerRadius = 12;
    self.previewCanvas.clipsToBounds = YES;
    self.previewCanvas.translatesAutoresizingMaskIntoConstraints = NO;
    [self.previewCanvas.heightAnchor constraintEqualToConstant:260].active = YES;
    [stack addArrangedSubview:self.previewCanvas];
    self.previewImageView = [UIImageView new];
    self.previewImageView.contentMode = UIViewContentModeScaleToFill;
    self.previewImageView.userInteractionEnabled = NO;
    self.previewImageView.translatesAutoresizingMaskIntoConstraints = YES;
    [self.previewCanvas addSubview:self.previewImageView];

    [self addSlider:@"X（水平，中心点）" min:-600 max:600 value:FISettings.shared.x toStack:stack];
    [self addSlider:@"Y（垂直，中心点）" min:-900 max:900 value:FISettings.shared.y toStack:stack];
    [self addSlider:@"宽度" min:20 max:900 value:FISettings.shared.width toStack:stack];
    [self addSlider:@"高度" min:20 max:1200 value:FISettings.shared.height toStack:stack];
    [self addSlider:@"透明度" min:0.05 max:1 value:FISettings.shared.alpha toStack:stack];

    self.toggleButton = [self button:@"开启悬浮" action:@selector(toggle)];
    self.toggleButton.titleLabel.font = [UIFont systemFontOfSize:18 weight:UIFontWeightSemibold];
    [stack addArrangedSubview:self.toggleButton];
    [stack addArrangedSubview:[self button:@"重置五项参数" action:@selector(resetValues)]];

    UILabel *note = [self label:@"1.1 更新：保留 GIF 原始文件并使用 ImageIO 读取动画帧；预览与悬浮显示共用图片解码逻辑。当前 UIWindow 仍是本 App 场景内实验，跨 App 常驻能力尚未接入。"];
    note.numberOfLines = 0;
    note.textColor = UIColor.secondaryLabelColor;
    [stack addArrangedSubview:note];
}

- (void)addSlider:(NSString *)name min:(float)min max:(float)max value:(float)value toStack:(UIStackView *)stack {
    UIStackView *row = [UIStackView new];
    row.axis = UILayoutConstraintAxisVertical;
    row.spacing = 4;
    [row addArrangedSubview:[self label:name]];
    UISlider *slider = [UISlider new];
    slider.minimumValue = min;
    slider.maximumValue = max;
    slider.value = value;
    [slider addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];
    [row addArrangedSubview:slider];
    [self.sliders addObject:slider];
    [stack addArrangedSubview:row];
}

- (void)pickImage {
    PHPickerConfiguration *config = [PHPickerConfiguration new];
    config.filter = PHPickerFilter.imagesFilter;
    config.selectionLimit = 1;
    PHPickerViewController *picker = [[PHPickerViewController alloc] initWithConfiguration:config];
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:nil];
}

- (NSURL *)applicationSupportURL {
    NSURL *dir = [NSFileManager.defaultManager URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject;
    [NSFileManager.defaultManager createDirectoryAtURL:dir withIntermediateDirectories:YES attributes:nil error:nil];
    return dir;
}

- (void)removePreviousImageFiles {
    NSURL *dir = [self applicationSupportURL];
    NSArray<NSURL *> *urls = [NSFileManager.defaultManager contentsOfDirectoryAtURL:dir includingPropertiesForKeys:nil options:NSDirectoryEnumerationSkipsHiddenFiles error:nil];
    for (NSURL *url in urls) {
        if ([url.lastPathComponent hasPrefix:@"FloatImage."]) [NSFileManager.defaultManager removeItemAtURL:url error:nil];
    }
}

- (void)picker:(PHPickerViewController *)picker didFinishPicking:(NSArray<PHPickerResult *> *)results {
    [picker dismissViewControllerAnimated:YES completion:nil];
    NSItemProvider *provider = results.firstObject.itemProvider;
    if (!provider) return;

    NSString *gifType = [UTType typeWithFilenameExtension:@"gif"].identifier;
    BOOL isGIF = [provider hasItemConformingToTypeIdentifier:gifType];
    NSString *typeIdentifier = isGIF ? gifType : [UTType typeWithIdentifier:@"public.image"].identifier;
    __weak typeof(self) weakSelf = self;
    [provider loadFileRepresentationForTypeIdentifier:typeIdentifier completionHandler:^(NSURL *temporaryURL, NSError *error) {
        if (!temporaryURL || error) {
            [weakSelf loadImageDataFallbackFromProvider:provider];
            return;
        }
        NSString *ext = isGIF ? @"gif" : (temporaryURL.pathExtension.length ? temporaryURL.pathExtension : @"img");
        [weakSelf removePreviousImageFiles];
        NSURL *destination = [[weakSelf applicationSupportURL] URLByAppendingPathComponent:[@"FloatImage" stringByAppendingPathExtension:ext]];
        NSError *copyError = nil;
        [[NSFileManager defaultManager] copyItemAtURL:temporaryURL toURL:destination error:&copyError];
        if (copyError) {
            dispatch_async(dispatch_get_main_queue(), ^{ weakSelf.status.text = [NSString stringWithFormat:@"图片保存失败：%@", copyError.localizedDescription]; });
            return;
        }
        [weakSelf adoptImageURL:destination];
    }];
}

- (void)loadImageDataFallbackFromProvider:(NSItemProvider *)provider {
    NSString *type = provider.registeredTypeIdentifiers.firstObject ?: [UTType typeWithIdentifier:@"public.image"].identifier;
    __weak typeof(self) weakSelf = self;
    [provider loadDataRepresentationForTypeIdentifier:type completionHandler:^(NSData *data, NSError *error) {
        if (!data || error) return;
        NSString *ext = [type.lowercaseString containsString:@"gif"] ? @"gif" : @"img";
        [weakSelf removePreviousImageFiles];
        NSURL *url = [[weakSelf applicationSupportURL] URLByAppendingPathComponent:[@"FloatImage" stringByAppendingPathExtension:ext]];
        if (![data writeToURL:url options:NSDataWritingAtomic error:nil]) return;
        [weakSelf adoptImageURL:url];
    }];
}

- (void)adoptImageURL:(NSURL *)url {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIImage *image = [FloatingController imageForURL:url];
        if (!image) { self.status.text = @"无法读取该图片格式"; return; }
        self.imageURL = url;
        self.previewImageView.image = image;
        self.status.text = [url.pathExtension.lowercaseString isEqualToString:@"gif"] ? @"已载入 GIF 动图" : @"已载入图片";
        [[FloatingController shared] showImageAtURL:url];
        [self updatePreview];
    });
}

- (void)loadSavedImage {
    NSURL *dir = [self applicationSupportURL];
    NSArray<NSURL *> *urls = [NSFileManager.defaultManager contentsOfDirectoryAtURL:dir includingPropertiesForKeys:nil options:NSDirectoryEnumerationSkipsHiddenFiles error:nil];
    NSURL *candidate = nil;
    for (NSURL *url in urls) {
        if ([url.lastPathComponent hasPrefix:@"FloatImage."]) { candidate = url; break; }
    }
    if (candidate) [self adoptImageURL:candidate];
}

- (void)sliderChanged:(UISlider *)slider {
    NSUInteger i = [self.sliders indexOfObject:slider];
    FISettings *s = FISettings.shared;
    switch (i) {
        case 0: s.x = slider.value; break;
        case 1: s.y = slider.value; break;
        case 2: s.width = slider.value; break;
        case 3: s.height = slider.value; break;
        case 4: s.alpha = slider.value; break;
    }
    [s save];
    [self updatePreview];
    [[FloatingController shared] refresh];
}

- (void)updatePreview {
    if (!self.previewImageView.image || !self.previewCanvas) return;
    FISettings *s = FISettings.shared;
    CGFloat scale = MIN(1.0, MIN(220.0 / MAX(1, s.width), 220.0 / MAX(1, s.height)));
    CGFloat width = MAX(1, s.width * scale);
    CGFloat height = MAX(1, s.height * scale);
    self.previewImageView.bounds = CGRectMake(0, 0, width, height);
    self.previewImageView.center = CGPointMake(CGRectGetMidX(self.previewCanvas.bounds) + s.x * 0.12,
                                               CGRectGetMidY(self.previewCanvas.bounds) + s.y * 0.12);
    self.previewImageView.alpha = s.alpha;
}

- (void)syncControls {
    FISettings *s = FISettings.shared;
    NSArray *values = @[@(s.x), @(s.y), @(s.width), @(s.height), @(s.alpha)];
    for (NSUInteger i = 0; i < MIN(values.count, self.sliders.count); i++) self.sliders[i].value = [values[i] floatValue];
    [self updatePreview];
    [self updateToggleTitle];
}

- (void)updateToggleTitle {
    [self.toggleButton setTitle:(FISettings.shared.isEnabled ? @"关闭悬浮" : @"开启悬浮") forState:UIControlStateNormal];
}

- (void)toggle {
    if (!self.imageURL && !FISettings.shared.isEnabled) { self.status.text = @"请先选择一张图片或 GIF"; return; }
    [[FloatingController shared] setEnabled:!FISettings.shared.isEnabled];
    [self updateToggleTitle];
}

- (void)resetValues {
    [FISettings.shared reset];
    [self syncControls];
    [[FloatingController shared] refresh];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self updatePreview];
}
@end

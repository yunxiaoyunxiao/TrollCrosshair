#import "AppDelegate.h"
#import "RootViewController.h"
#import "FISettings.h"
#import "FloatingController.h"

@implementation AppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.rootViewController = [RootViewController new];
    [self.window makeKeyAndVisible];
    return YES;
}

// Shortcuts can invoke floatimage://toggle, floatimage://show or floatimage://hide.
// iOS may bring the app to the foreground to deliver a custom URL; this is not
// a claim of background/system-level execution.
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {
    if (![url.scheme.lowercaseString isEqualToString:@"floatimage"]) return NO;
    NSString *action = url.host.lowercaseString ?: url.path.lowercaseString;
    BOOL enabled = FISettings.shared.isEnabled;
    if ([action isEqualToString:@"toggle"]) enabled = !enabled;
    else if ([action isEqualToString:@"show"] || [action isEqualToString:@"on"]) enabled = YES;
    else if ([action isEqualToString:@"hide"] || [action isEqualToString:@"off"]) enabled = NO;
    else return NO;
    [[FloatingController shared] setEnabled:enabled];
    return YES;
}
@end

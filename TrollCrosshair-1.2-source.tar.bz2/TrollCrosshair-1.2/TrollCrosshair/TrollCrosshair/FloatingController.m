#import "FloatingController.h"
#import "FISettings.h"
#import <ImageIO/ImageIO.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <notify.h>
#import <spawn.h>
#import <signal.h>
#import <unistd.h>
#import <dlfcn.h>
#import <stdlib.h>
#import <errno.h>
#import <string.h>

extern char **environ;
static NSString * const TCFloatingRefreshNotification = @"com.trollcrosshair.refresh";
static NSString * const TCFloatingReadyNotification = @"com.trollcrosshair.ready";

static NSURL *TCHUDDirectory(void) {
    NSURL *directory = [NSFileManager.defaultManager URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject;
    if (directory) [NSFileManager.defaultManager createDirectoryAtURL:directory withIntermediateDirectories:YES attributes:nil error:nil];
    return directory;
}
static NSURL *TCHUDPIDURL(void) { return [TCHUDDirectory() URLByAppendingPathComponent:@"TrollCrosshair-HUD.pid"]; }
static NSURL *TCHUDStateURL(void) { return [TCHUDDirectory() URLByAppendingPathComponent:@"TrollCrosshair-HUD.status"]; }
static NSURL *TCHUDLogURL(void) { return [TCHUDDirectory() URLByAppendingPathComponent:@"TrollCrosshair-diagnostics.log"]; }

static void TCHUDLog(NSString *message) {
    NSString *line = [NSString stringWithFormat:@"[%@] %@\n", [NSDate date], message ?: @""]; 
    NSLog(@"[TrollCrosshair] %@", message);
    NSURL *url = TCHUDLogURL();
    if (!url) return;
    NSData *data = [line dataUsingEncoding:NSUTF8StringEncoding];
    @synchronized (TCHUDLogURL()) {
        if (![NSFileManager.defaultManager fileExistsAtPath:url.path]) [data writeToURL:url options:NSDataWritingAtomic error:nil];
        else {
            NSFileHandle *handle = [NSFileHandle fileHandleForWritingAtPath:url.path];
            [handle seekToEndOfFile]; [handle writeData:data]; [handle closeFile];
        }
    }
}
static void TCHUDWriteState(NSString *state) {
    [state writeToURL:TCHUDStateURL() atomically:YES encoding:NSUTF8StringEncoding error:nil];
    TCHUDLog([NSString stringWithFormat:@"HUD_STATE=%@", state]);
}
static NSString *TCHUDReadState(void) {
    return [NSString stringWithContentsOfURL:TCHUDStateURL() encoding:NSUTF8StringEncoding error:nil];
}
static NSURL *TCHUDSavedImageURL(void) {
    NSArray<NSURL *> *files = [NSFileManager.defaultManager contentsOfDirectoryAtURL:TCHUDDirectory() includingPropertiesForKeys:nil options:NSDirectoryEnumerationSkipsHiddenFiles error:nil];
    NSSet *imageExtensions = [NSSet setWithArray:@[@"png", @"jpg", @"jpeg", @"gif", @"heic", @"webp", @"bmp", @"tif", @"tiff"]];
    for (NSURL *file in files) {
        NSString *name = file.lastPathComponent;
        if (([name hasPrefix:@"TrollCrosshair."] || [name hasPrefix:@"FloatImage."]) && [imageExtensions containsObject:file.pathExtension.lowercaseString]) return file;
    }
    return nil;
}

@interface TCHUDWindow : UIWindow @end
@implementation TCHUDWindow
+ (BOOL)_isSystemWindow { return YES; }
- (BOOL)_isWindowServerHostingManaged { return NO; }
- (BOOL)_ignoresHitTest { return YES; }
- (BOOL)_isSecure { return YES; }
- (BOOL)_shouldCreateContextAsSecure { return YES; }
@end

@interface TCHUDProcessDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) UIImageView *imageView;
@property(nonatomic,strong) id hostingController;
- (void)reloadOverlay;
@end
@implementation TCHUDProcessDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    TCHUDLog(@"HUD delegate didFinishLaunching entered");
    self.window = [[TCHUDWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.windowLevel = (UIWindowLevel)10000010.0;
    self.window.backgroundColor = UIColor.clearColor;
    self.window.opaque = NO;
    UIViewController *root = [UIViewController new]; root.view.backgroundColor = UIColor.clearColor;
    self.imageView = [UIImageView new]; self.imageView.backgroundColor = UIColor.clearColor;
    self.imageView.contentMode = UIViewContentModeScaleToFill; self.imageView.userInteractionEnabled = NO;
    [root.view addSubview:self.imageView]; self.window.rootViewController = root;

    Class hostClass = objc_getClass("SBSAccessibilityWindowHostingController");
    SEL contextSelector = sel_registerName("_contextId");
    SEL registerSelector = sel_registerName("registerWindowWithContextID:atLevel:");
    if (!hostClass) {
        TCHUDWriteState(@"ERROR: BackBoard hosting class SBSAccessibilityWindowHostingController not found");
        return YES;
    }
    if (![self.window respondsToSelector:contextSelector]) {
        TCHUDWriteState(@"ERROR: UIWindow _contextId selector unavailable");
        return YES;
    }
    self.hostingController = [[hostClass alloc] init];
    if (!self.hostingController || ![self.hostingController respondsToSelector:registerSelector]) {
        TCHUDWriteState(@"ERROR: hosting controller registerWindowWithContextID:atLevel: unavailable");
        return YES;
    }
    unsigned int contextID = ((unsigned int (*)(id, SEL))objc_msgSend)(self.window, contextSelector);
    if (contextID == 0) {
        TCHUDWriteState(@"ERROR: UIWindow returned context ID 0");
        return YES;
    }
    double level = self.window.windowLevel;
    @try {
        NSMethodSignature *sig = [self.hostingController methodSignatureForSelector:registerSelector];
        if (!sig || sig.numberOfArguments != 4) {
            TCHUDWriteState(@"ERROR: unexpected BackBoard registration method signature");
            return YES;
        }
        NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
        [inv setTarget:self.hostingController]; [inv setSelector:registerSelector];
        [inv setArgument:&contextID atIndex:2]; [inv setArgument:&level atIndex:3]; [inv invoke];
        TCHUDLog([NSString stringWithFormat:@"BackBoard registration invoked; context=%u level=%.1f", contextID, level]);
    } @catch (NSException *e) {
        TCHUDWriteState([NSString stringWithFormat:@"ERROR: BackBoard registration exception: %@", e.reason ?: e.name]);
        return YES;
    }

    [self.window setHidden:NO]; [self.window makeKeyAndVisible];
    int token = 0;
    uint32_t notifyResult = notify_register_dispatch(TCFloatingRefreshNotification.UTF8String, &token, dispatch_get_main_queue(), ^(int t) { [self reloadOverlay]; });
    TCHUDLog([NSString stringWithFormat:@"Refresh notification registration result=%u", notifyResult]);
    [self reloadOverlay];
    TCHUDWriteState(@"READY: BackBoard registration invoked; HUD event loop active");
    notify_post(TCFloatingReadyNotification.UTF8String);
    return YES;
}
- (void)reloadOverlay {
    [FISettings.shared reload];
    NSURL *url = TCHUDSavedImageURL();
    UIImage *image = url ? [FloatingController imageForURL:url] : nil;
    self.imageView.image = image;
    self.imageView.hidden = (image == nil);
    if (!image) { self.window.hidden = YES; TCHUDLog(@"HUD refresh: image file missing or unreadable"); return; }
    FISettings *s = FISettings.shared;
    CGFloat longest = MAX(image.size.width, image.size.height);
    CGFloat factor = longest > 0 ? (180.0 * (s.sizeScale / 100.0)) / longest : 1.0;
    CGFloat width = MAX(1.0, image.size.width * factor), height = MAX(1.0, image.size.height * factor);
    CGRect screen = self.window.bounds; UIEdgeInsets safe = self.window.safeAreaInsets;
    CGRect usable = UIEdgeInsetsInsetRect(screen, safe);
    self.imageView.bounds = CGRectMake(0, 0, width, height);
    self.imageView.center = CGPointMake(CGRectGetMidX(usable) + s.x, CGRectGetMidY(usable) + s.y);
    self.imageView.alpha = MIN(1.0, MAX(0.0, s.alpha));
    self.window.hidden = !s.enabled;
}
@end

@interface TCHUDApplication : UIApplication @end
@implementation TCHUDApplication @end
@interface UIApplication (TCHUDPrivate)
- (void)_accessibilityInit;
- (void)__completeAndRunAsPlugin;
@end

@interface FloatingController ()
@property(nonatomic,strong) NSURL *imageURL;
@property(nonatomic,assign) pid_t hudPID;
@end
@implementation FloatingController
+ (instancetype)shared { static FloatingController *c; static dispatch_once_t once; dispatch_once(&once, ^{ c = [FloatingController new]; }); return c; }
+ (UIImage *)imageForURL:(NSURL *)url {
    if (!url) return nil;
    NSData *data = [NSData dataWithContentsOfURL:url options:NSDataReadingMappedIfSafe error:nil]; if (!data) return nil;
    CGImageSourceRef source = CGImageSourceCreateWithData((__bridge CFDataRef)data, NULL); if (!source) return [UIImage imageWithData:data];
    size_t count = CGImageSourceGetCount(source);
    if (count <= 1) { CGImageRef cg = CGImageSourceCreateImageAtIndex(source, 0, NULL); UIImage *img = cg ? [UIImage imageWithCGImage:cg scale:UIScreen.mainScreen.scale orientation:UIImageOrientationUp] : [UIImage imageWithData:data]; if (cg) CGImageRelease(cg); CFRelease(source); return img; }
    NSMutableArray<UIImage *> *frames = [NSMutableArray arrayWithCapacity:count]; NSTimeInterval duration = 0;
    for (size_t i=0; i<count; i++) { CGImageRef cg=CGImageSourceCreateImageAtIndex(source,i,NULL); if(!cg) continue; [frames addObject:[UIImage imageWithCGImage:cg scale:UIScreen.mainScreen.scale orientation:UIImageOrientationUp]]; CGImageRelease(cg); NSDictionary *props=CFBridgingRelease(CGImageSourceCopyPropertiesAtIndex(source,i,NULL)); NSDictionary *gif=props[(NSString *)kCGImagePropertyGIFDictionary]; NSNumber *delay=gif[(NSString *)kCGImagePropertyGIFUnclampedDelayTime] ?: gif[(NSString *)kCGImagePropertyGIFDelayTime]; duration += (delay.doubleValue >= 0.02 ? delay.doubleValue : 0.1); }
    CFRelease(source); if (!frames.count) return [UIImage imageWithData:data]; if (frames.count==1) return frames.firstObject; return [UIImage animatedImageWithImages:frames duration:MAX(duration, frames.count*0.1)];
}
- (NSString *)diagnosticLog {
    NSMutableString *result = [NSMutableString stringWithFormat:@"TrollCrosshair 1.2 Build 6\niOS: %@\nDevice: %@\nHUD status: %@\nHUD PID: %d\n\n", UIDevice.currentDevice.systemVersion, UIDevice.currentDevice.model, TCHUDReadState() ?: @"(no status)", self.hudPID];
    NSString *log = [NSString stringWithContentsOfURL:TCHUDLogURL() encoding:NSUTF8StringEncoding error:nil];
    [result appendString:log ?: @"(no diagnostic log)"];
    return result;
}
- (BOOL)performShortcutCommand:(NSString *)command {
    NSString *action = command.lowercaseString; BOOL next = FISettings.shared.isEnabled;
    if ([action isEqualToString:@"toggle"]) next = !next;
    else if ([action isEqualToString:@"on"] || [action isEqualToString:@"show"]) next = YES;
    else if ([action isEqualToString:@"off"] || [action isEqualToString:@"hide"]) next = NO; else return NO;
    TCHUDLog([NSString stringWithFormat:@"Shortcut command received: %@", action]);
    NSURL *image = self.imageURL ?: TCHUDSavedImageURL();
    if (next && (!image || ![NSFileManager.defaultManager fileExistsAtPath:image.path])) { TCHUDLog(@"Shortcut rejected: no saved image file"); return NO; }
    if (image) self.imageURL = image;
    BOOL success = [self setEnabled:next];
    TCHUDLog([NSString stringWithFormat:@"Shortcut command %@ result=%@", action, success ? @"success" : @"failure"]);
    return success;
}
- (BOOL)isHUDRunning {
    pid_t pid = self.hudPID;
    if (pid <= 0) pid = (pid_t)[[NSString stringWithContentsOfURL:TCHUDPIDURL() encoding:NSUTF8StringEncoding error:nil] intValue];
    return pid > 0 && kill(pid, 0) == 0;
}
- (void)showImageAtURL:(NSURL *)url { if (url) self.imageURL = url; TCHUDLog([NSString stringWithFormat:@"Image selected: extension=%@", url.pathExtension.lowercaseString]); notify_post(TCFloatingRefreshNotification.UTF8String); }
- (void)refresh { notify_post(TCFloatingRefreshNotification.UTF8String); }
- (BOOL)startHUDProcess {
    if ([self isHUDRunning]) {
        TCHUDLog(@"HUD process already running; sending refresh"); notify_post(TCFloatingRefreshNotification.UTF8String);
        return [TCHUDReadState() hasPrefix:@"READY:"];
    }
    NSString *path = NSBundle.mainBundle.executablePath;
    if (!path.length) { TCHUDLog(@"ERROR: main executable path unavailable"); return NO; }
    [NSFileManager.defaultManager removeItemAtURL:TCHUDStateURL() error:nil];
    char *argv[] = {(char *)path.UTF8String, "-hud", NULL}; pid_t pid = 0;
    int result = posix_spawn(&pid, path.fileSystemRepresentation, NULL, NULL, argv, environ);
    if (result != 0) {
        TCHUDLog([NSString stringWithFormat:@"ERROR: posix_spawn failed: %d (%s)", result, strerror(result)]);
        TCHUDWriteState([NSString stringWithFormat:@"ERROR: posix_spawn failed %d (%s)", result, strerror(result)]);
        return NO;
    }
    self.hudPID = pid;
    [[NSString stringWithFormat:@"%d", pid] writeToURL:TCHUDPIDURL() atomically:YES encoding:NSUTF8StringEncoding error:nil];
    TCHUDLog([NSString stringWithFormat:@"HUD process spawned pid=%d executable=%@", pid, path.lastPathComponent]);
    NSDate *deadline = [NSDate dateWithTimeIntervalSinceNow:3.0];
    while ([deadline timeIntervalSinceNow] > 0) {
        NSString *state = TCHUDReadState();
        if ([state hasPrefix:@"READY:"]) { TCHUDLog(@"HUD startup handshake succeeded"); return YES; }
        if ([state hasPrefix:@"ERROR:"]) { TCHUDLog([NSString stringWithFormat:@"HUD startup failed: %@", state]); return NO; }
        if (kill(pid, 0) != 0) { TCHUDLog([NSString stringWithFormat:@"ERROR: HUD process exited before ready; errno=%d", errno]); return NO; }
        [NSThread sleepForTimeInterval:0.1];
    }
    TCHUDLog([NSString stringWithFormat:@"ERROR: HUD startup timed out; last state=%@", TCHUDReadState() ?: @"(none)"]);
    return NO;
}
- (void)stopHUDProcess {
    pid_t pid = self.hudPID; if (pid <= 0) pid = (pid_t)[[NSString stringWithContentsOfURL:TCHUDPIDURL() encoding:NSUTF8StringEncoding error:nil] intValue];
    if (pid > 0 && kill(pid, 0) == 0) { kill(pid, SIGTERM); TCHUDLog([NSString stringWithFormat:@"Sent SIGTERM to HUD pid=%d", pid]); }
    self.hudPID = 0;
    [NSFileManager.defaultManager removeItemAtURL:TCHUDPIDURL() error:nil];
}
- (BOOL)setEnabled:(BOOL)enabled {
    FISettings.shared.enabled = enabled; [FISettings.shared save];
    if (!enabled) { [self stopHUDProcess]; TCHUDWriteState(@"STOPPED: disabled by user"); return YES; }
    BOOL started = [self startHUDProcess];
    if (!started) {
        FISettings.shared.enabled = NO; [FISettings.shared save];
        [self stopHUDProcess];
        return NO;
    }
    return YES;
}
@end

static void *TCHUDSymbol(const char *name, const char *frameworkPath) {
    void *handle = dlopen(frameworkPath, RTLD_NOW); void *symbol = dlsym(handle ?: RTLD_DEFAULT, name); if (!symbol) symbol = dlsym(RTLD_DEFAULT, name);
    TCHUDLog([NSString stringWithFormat:@"Symbol %@: %@", [NSString stringWithUTF8String:name], symbol ? @"found" : @"missing"]);
    return symbol;
}
int TCHUDMain(void) {
    @autoreleasepool {
        TCHUDWriteState(@"STARTING: entering HUD bootstrap");
        TCHUDLog([NSString stringWithFormat:@"HUD bootstrap process pid=%d", getpid()]);
        [UIScreen initialize]; CFRunLoopGetCurrent();
        typedef void (*VoidFunction)(void); typedef void (*InstantiateFunction)(id);
        VoidFunction gs=(VoidFunction)TCHUDSymbol("GSInitialize", "/System/Library/PrivateFrameworks/GraphicsServices.framework/GraphicsServices");
        VoidFunction bks=(VoidFunction)TCHUDSymbol("BKSDisplayServicesStart", "/System/Library/PrivateFrameworks/BackBoardServices.framework/BackBoardServices");
        VoidFunction ui=(VoidFunction)TCHUDSymbol("UIApplicationInitialize", "/System/Library/PrivateFrameworks/UIKitCore.framework/UIKitCore");
        InstantiateFunction instantiate=(InstantiateFunction)TCHUDSymbol("UIApplicationInstantiateSingleton", "/System/Library/PrivateFrameworks/UIKitCore.framework/UIKitCore");
        if (!gs || !bks || !ui || !instantiate) { TCHUDWriteState(@"ERROR: required UIKit/BackBoard bootstrap symbol missing"); return EXIT_FAILURE; }
        gs(); TCHUDLog(@"GSInitialize completed");
        bks(); TCHUDLog(@"BKSDisplayServicesStart completed");
        ui(); TCHUDLog(@"UIApplicationInitialize completed");
        instantiate(TCHUDApplication.class); TCHUDLog(@"UIApplication singleton instantiated");
        UIApplication *app=UIApplication.sharedApplication;
        static TCHUDProcessDelegate *delegate=nil; delegate=[TCHUDProcessDelegate new]; [app setDelegate:delegate];
        [app _accessibilityInit]; TCHUDLog(@"UIApplication _accessibilityInit completed");
        typedef void (*EventInit)(Boolean); typedef void (*PushMode)(CFStringRef);
        EventInit eventInit=(EventInit)TCHUDSymbol("GSEventInitialize", "/System/Library/PrivateFrameworks/GraphicsServices.framework/GraphicsServices");
        PushMode pushMode=(PushMode)TCHUDSymbol("GSEventPushRunLoopMode", "/System/Library/PrivateFrameworks/GraphicsServices.framework/GraphicsServices");
        if (eventInit) eventInit(0); if (pushMode) pushMode(kCFRunLoopDefaultMode);
        TCHUDLog(@"Calling UIApplication __completeAndRunAsPlugin");
        [app __completeAndRunAsPlugin];
        TCHUDLog(@"__completeAndRunAsPlugin returned; entering CFRunLoopRun");
        CFRunLoopRun();
        TCHUDWriteState(@"ERROR: HUD run loop exited unexpectedly");
        return EXIT_FAILURE;
    }
}

#import "FloatingController.h"
#import "FISettings.h"
#import <ImageIO/ImageIO.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <notify.h>
#import <spawn.h>
#import <signal.h>
#import <unistd.h>
#import <dlfcn.h>
#import <stdlib.h>

extern char **environ;
static NSString * const TCFloatingRefreshNotification = @"com.trollcrosshair.refresh";
static NSString * const TCFloatingReadyNotification = @"com.trollcrosshair.ready";

static NSURL *TCHUDDirectory(void) {
    NSURL *directory = [NSFileManager.defaultManager URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject;
    [NSFileManager.defaultManager createDirectoryAtURL:directory withIntermediateDirectories:YES attributes:nil error:nil];
    return directory;
}
static NSURL *TCHUDPIDURL(void) { return [TCHUDDirectory() URLByAppendingPathComponent:@"TrollCrosshair-HUD.pid"]; }
static NSURL *TCHUDSavedImageURL(void) {
    NSArray<NSURL *> *files = [NSFileManager.defaultManager contentsOfDirectoryAtURL:TCHUDDirectory() includingPropertiesForKeys:nil options:NSDirectoryEnumerationSkipsHiddenFiles error:nil];
    NSSet *imageExtensions = [NSSet setWithArray:@[@"png", @"jpg", @"jpeg", @"gif", @"heic", @"webp", @"bmp", @"tif", @"tiff"]];
    for (NSURL *file in files) {
        NSString *name = file.lastPathComponent;
        if (([name hasPrefix:@"TrollCrosshair."] || [name hasPrefix:@"FloatImage."]) && [imageExtensions containsObject:file.pathExtension.lowercaseString]) return file;
    }
    return nil;
}

@interface TCHUDWindow : UIWindow @end
@implementation TCHUDWindow
+ (BOOL)_isSystemWindow { return YES; }
- (BOOL)_isWindowServerHostingManaged { return NO; }
- (BOOL)_ignoresHitTest { return YES; }
- (BOOL)_isSecure { return YES; }
- (BOOL)_shouldCreateContextAsSecure { return YES; }
@end

@interface TCHUDProcessDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong) UIWindow *window;
@property(nonatomic,strong) UIImageView *imageView;
@property(nonatomic,strong) id hostingController;
- (void)reloadOverlay;
@end
@implementation TCHUDProcessDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[TCHUDWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.windowLevel = (UIWindowLevel)10000010.0;
    self.window.backgroundColor = UIColor.clearColor;
    self.window.opaque = NO;
    UIViewController *root = [UIViewController new]; root.view.backgroundColor = UIColor.clearColor;
    self.imageView = [UIImageView new]; self.imageView.backgroundColor = UIColor.clearColor;
    self.imageView.contentMode = UIViewContentModeScaleToFill; self.imageView.userInteractionEnabled = NO;
    [root.view addSubview:self.imageView]; self.window.rootViewController = root;
    [self.window setHidden:NO]; [self.window makeKeyAndVisible];

    Class hostClass = objc_getClass("SBSAccessibilityWindowHostingController");
    SEL contextSelector = sel_registerName("_contextId");
    if (hostClass && [self.window respondsToSelector:contextSelector]) {
        self.hostingController = [[hostClass alloc] init];
        unsigned int contextID = ((unsigned int (*)(id, SEL))objc_msgSend)(self.window, contextSelector);
        double level = self.window.windowLevel;
        @try {
            NSMethodSignature *sig = [NSMethodSignature signatureWithObjCTypes:"v@:Id"];
            NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
            [inv setTarget:self.hostingController];
            [inv setSelector:sel_registerName("registerWindowWithContextID:atLevel:")];
            [inv setArgument:&contextID atIndex:2]; [inv setArgument:&level atIndex:3]; [inv invoke];
            NSLog(@"[TrollCrosshair HUD] registered BackBoard context %u at %.1f", contextID, level);
        } @catch (NSException *e) { NSLog(@"[TrollCrosshair HUD] registration exception: %@", e); }
    } else {
        NSLog(@"[TrollCrosshair HUD] BackBoard hosting API unavailable");
    }
    int token = 0;
    notify_register_dispatch(TCFloatingRefreshNotification.UTF8String, &token, dispatch_get_main_queue(), ^(int t) { [self reloadOverlay]; });
    [self reloadOverlay]; notify_post(TCFloatingReadyNotification.UTF8String);
    return YES;
}
- (void)reloadOverlay {
    [FISettings.shared reload];
    NSURL *url = TCHUDSavedImageURL();
    UIImage *image = url ? [FloatingController imageForURL:url] : nil;
    self.imageView.image = image;
    self.imageView.hidden = (image == nil);
    if (!image) { self.window.hidden = YES; return; }
    FISettings *s = FISettings.shared;
    CGFloat longest = MAX(image.size.width, image.size.height);
    CGFloat factor = longest > 0 ? (180.0 * (s.sizeScale / 100.0)) / longest : 1.0;
    CGFloat width = MAX(1.0, image.size.width * factor), height = MAX(1.0, image.size.height * factor);
    CGRect screen = self.window.bounds; UIEdgeInsets safe = self.window.safeAreaInsets;
    CGRect usable = UIEdgeInsetsInsetRect(screen, safe);
    self.imageView.bounds = CGRectMake(0, 0, width, height);
    self.imageView.center = CGPointMake(CGRectGetMidX(usable) + s.x, CGRectGetMidY(usable) + s.y);
    self.imageView.alpha = MIN(1.0, MAX(0.0, s.alpha));
    self.window.hidden = !s.enabled;
}
@end

@interface TCHUDApplication : UIApplication @end
@implementation TCHUDApplication @end
@interface UIApplication (TCHUDPrivate)
- (void)_accessibilityInit;
- (void)__completeAndRunAsPlugin;
@end

@interface FloatingController ()
@property(nonatomic,strong) NSURL *imageURL;
@property(nonatomic,assign) pid_t hudPID;
@end
@implementation FloatingController
+ (instancetype)shared { static FloatingController *c; static dispatch_once_t once; dispatch_once(&once, ^{ c = [FloatingController new]; }); return c; }
+ (UIImage *)imageForURL:(NSURL *)url {
    if (!url) return nil;
    NSData *data = [NSData dataWithContentsOfURL:url options:NSDataReadingMappedIfSafe error:nil]; if (!data) return nil;
    CGImageSourceRef source = CGImageSourceCreateWithData((__bridge CFDataRef)data, NULL); if (!source) return [UIImage imageWithData:data];
    size_t count = CGImageSourceGetCount(source);
    if (count <= 1) { CGImageRef cg = CGImageSourceCreateImageAtIndex(source, 0, NULL); UIImage *img = cg ? [UIImage imageWithCGImage:cg scale:UIScreen.mainScreen.scale orientation:UIImageOrientationUp] : [UIImage imageWithData:data]; if (cg) CGImageRelease(cg); CFRelease(source); return img; }
    NSMutableArray<UIImage *> *frames = [NSMutableArray arrayWithCapacity:count]; NSTimeInterval duration = 0;
    for (size_t i=0; i<count; i++) { CGImageRef cg=CGImageSourceCreateImageAtIndex(source,i,NULL); if(!cg) continue; [frames addObject:[UIImage imageWithCGImage:cg scale:UIScreen.mainScreen.scale orientation:UIImageOrientationUp]]; CGImageRelease(cg); NSDictionary *props=CFBridgingRelease(CGImageSourceCopyPropertiesAtIndex(source,i,NULL)); NSDictionary *gif=props[(NSString *)kCGImagePropertyGIFDictionary]; NSNumber *delay=gif[(NSString *)kCGImagePropertyGIFUnclampedDelayTime] ?: gif[(NSString *)kCGImagePropertyGIFDelayTime]; duration += (delay.doubleValue >= 0.02 ? delay.doubleValue : 0.1); }
    CFRelease(source); if (!frames.count) return [UIImage imageWithData:data]; if (frames.count==1) return frames.firstObject; return [UIImage animatedImageWithImages:frames duration:MAX(duration, frames.count*0.1)];
}
- (BOOL)performShortcutCommand:(NSString *)command {
    NSString *action = command.lowercaseString; BOOL next = FISettings.shared.isEnabled;
    if ([action isEqualToString:@"toggle"]) next = !next;
    else if ([action isEqualToString:@"on"] || [action isEqualToString:@"show"]) next = YES;
    else if ([action isEqualToString:@"off"] || [action isEqualToString:@"hide"]) next = NO; else return NO;
    NSURL *image = self.imageURL ?: TCHUDSavedImageURL();
    if (next && (!image || ![NSFileManager.defaultManager fileExistsAtPath:image.path])) return NO;
    if (image) self.imageURL = image; [self setEnabled:next]; return YES;
}
- (BOOL)isHUDRunning {
    pid_t pid = self.hudPID;
    if (pid <= 0) pid = (pid_t)[[NSString stringWithContentsOfURL:TCHUDPIDURL() encoding:NSUTF8StringEncoding error:nil] intValue];
    return pid > 0 && kill(pid, 0) == 0;
}
- (void)showImageAtURL:(NSURL *)url { if (url) self.imageURL = url; notify_post(TCFloatingRefreshNotification.UTF8String); }
- (void)refresh { notify_post(TCFloatingRefreshNotification.UTF8String); }
- (void)startHUDProcess {
    if ([self isHUDRunning]) { notify_post(TCFloatingRefreshNotification.UTF8String); return; }
    NSString *path = NSBundle.mainBundle.executablePath; if (!path.length) return;
    char *argv[] = {(char *)path.UTF8String, "-hud", NULL}; pid_t pid = 0;
    int result = posix_spawn(&pid, path.fileSystemRepresentation, NULL, NULL, argv, environ);
    if (result != 0) { NSLog(@"[TrollCrosshair] posix_spawn failed: %d", result); return; }
    self.hudPID = pid; [[NSString stringWithFormat:@"%d", pid] writeToURL:TCHUDPIDURL() atomically:YES encoding:NSUTF8StringEncoding error:nil];
    NSLog(@"[TrollCrosshair] HUD process spawned: %d", pid);
}
- (void)stopHUDProcess {
    pid_t pid = self.hudPID; if (pid <= 0) pid = (pid_t)[[NSString stringWithContentsOfURL:TCHUDPIDURL() encoding:NSUTF8StringEncoding error:nil] intValue];
    if (pid > 0 && kill(pid, 0) == 0) kill(pid, SIGTERM); self.hudPID = 0;
    [NSFileManager.defaultManager removeItemAtURL:TCHUDPIDURL() error:nil];
}
- (void)setEnabled:(BOOL)enabled {
    FISettings.shared.enabled = enabled; [FISettings.shared save];
    if (enabled) [self startHUDProcess]; else [self stopHUDProcess];
}
@end

static void *TCHUDSymbol(const char *name, const char *frameworkPath) {
    void *handle = dlopen(frameworkPath, RTLD_NOW); void *symbol = dlsym(handle ?: RTLD_DEFAULT, name); if (!symbol) symbol = dlsym(RTLD_DEFAULT, name); return symbol;
}
int TCHUDMain(void) {
    @autoreleasepool {
        [UIScreen initialize]; CFRunLoopGetCurrent();
        typedef void (*VoidFunction)(void); typedef void (*InstantiateFunction)(id);
        VoidFunction gs=(VoidFunction)TCHUDSymbol("GSInitialize", "/System/Library/PrivateFrameworks/GraphicsServices.framework/GraphicsServices");
        VoidFunction bks=(VoidFunction)TCHUDSymbol("BKSDisplayServicesStart", "/System/Library/PrivateFrameworks/BackBoardServices.framework/BackBoardServices");
        VoidFunction ui=(VoidFunction)TCHUDSymbol("UIApplicationInitialize", "/System/Library/PrivateFrameworks/UIKitCore.framework/UIKitCore");
        InstantiateFunction instantiate=(InstantiateFunction)TCHUDSymbol("UIApplicationInstantiateSingleton", "/System/Library/PrivateFrameworks/UIKitCore.framework/UIKitCore");
        if (!gs || !bks || !ui || !instantiate) { NSLog(@"[TrollCrosshair HUD] bootstrap symbols missing"); return EXIT_FAILURE; }
        gs(); bks(); ui(); instantiate(TCHUDApplication.class);
        UIApplication *app=UIApplication.sharedApplication; static TCHUDProcessDelegate *delegate=nil; delegate=[TCHUDProcessDelegate new]; [app setDelegate:delegate]; [app _accessibilityInit];
        typedef void (*EventInit)(Boolean); typedef void (*PushMode)(CFStringRef);
        EventInit eventInit=(EventInit)TCHUDSymbol("GSEventInitialize", "/System/Library/PrivateFrameworks/GraphicsServices.framework/GraphicsServices");
        PushMode pushMode=(PushMode)TCHUDSymbol("GSEventPushRunLoopMode", "/System/Library/PrivateFrameworks/GraphicsServices.framework/GraphicsServices");
        if (eventInit) eventInit(0); if (pushMode) pushMode(kCFRunLoopDefaultMode);
        [app __completeAndRunAsPlugin]; CFRunLoopRun(); return EXIT_SUCCESS;
    }
}

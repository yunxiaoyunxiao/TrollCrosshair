import AppIntents
import Foundation

@available(iOS 17.0, *)
struct ToggleFloatingIntent: AppIntent {
    static var title: LocalizedStringResource = "切换图片悬浮"
    static var description = IntentDescription("打开 TrollCrosshair 并切换图片悬浮。")
    static var openAppWhenRun = true

    func perform() async throws -> some IntentResult {
        let succeeded = await MainActor.run {
            FloatingController.shared().performShortcutCommand("toggle")
        }
        return .result(dialog: succeeded ? "悬浮开关已执行。" : "悬浮启动失败，请在 TrollCrosshair 中复制诊断日志。")
    }
}

@available(iOS 17.0, *)
struct EnableFloatingIntent: AppIntent {
    static var title: LocalizedStringResource = "开启图片悬浮"
    static var description = IntentDescription("打开 TrollCrosshair 并开启图片悬浮。")
    static var openAppWhenRun = true

    func perform() async throws -> some IntentResult {
        let succeeded = await MainActor.run {
            FloatingController.shared().performShortcutCommand("on")
        }
        return .result(dialog: succeeded ? "图片悬浮已开启。" : "开启失败，请在 TrollCrosshair 中复制诊断日志。")
    }
}

@available(iOS 17.0, *)
struct DisableFloatingIntent: AppIntent {
    static var title: LocalizedStringResource = "关闭图片悬浮"
    static var description = IntentDescription("打开 TrollCrosshair 并关闭图片悬浮。")
    static var openAppWhenRun = true

    func perform() async throws -> some IntentResult {
        let succeeded = await MainActor.run {
            FloatingController.shared().performShortcutCommand("off")
        }
        return .result(dialog: succeeded ? "图片悬浮已关闭。" : "关闭操作失败。")
    }
}

@available(iOS 17.0, *)
struct FloatingAppShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(intent: ToggleFloatingIntent(), phrases: [
            "切换图片悬浮，使用\(.applicationName)",
            "悬浮开关，使用\(.applicationName)"
        ], shortTitle: "悬浮开关", systemImageName: "rectangle.on.rectangle")
        AppShortcut(intent: EnableFloatingIntent(), phrases: [
            "开启图片悬浮，使用\(.applicationName)"
        ], shortTitle: "开启悬浮", systemImageName: "rectangle.on.rectangle")
        AppShortcut(intent: DisableFloatingIntent(), phrases: [
            "关闭图片悬浮，使用\(.applicationName)"
        ], shortTitle: "关闭悬浮", systemImageName: "rectangle.slash")
    }
}

#import "RootViewController.h"
#import <PhotosUI/PhotosUI.h>
#import <UniformTypeIdentifiers/UniformTypeIdentifiers.h>
#import "FISettings.h"
#import "FloatingController.h"

@interface RootViewController () <PHPickerViewControllerDelegate>
@property(nonatomic,strong) UIImageView *previewImageView;
@property(nonatomic,strong) UIView *previewCanvas;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic,strong) UIButton *toggleButton;
@property(nonatomic,strong) NSURL *imageURL;
@property(nonatomic,strong) NSMutableArray<UISlider *> *sliders;
@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    self.sliders = [NSMutableArray array];
    [self buildUI];
    [self loadSavedImage];
    [self syncControls];
}

- (UILabel *)label:(NSString *)text {
    UILabel *l = [UILabel new];
    l.text = text;
    l.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    return l;
}

- (UIButton *)button:(NSString *)title action:(SEL)action {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    [b setTitle:title forState:UIControlStateNormal];
    [b addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return b;
}

- (void)buildUI {
    UIScrollView *scroll = [UIScrollView new];
    scroll.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:scroll];
    [NSLayoutConstraint activateConstraints:@[
        [scroll.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:8],
        [scroll.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
        [scroll.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:18],
        [scroll.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor]
    ]];

    UIStackView *stack = [[UIStackView alloc] init];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 12;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [scroll addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor],
        [stack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor constant:-20],
        [stack.leadingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.leadingAnchor],
        [stack.trailingAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.trailingAnchor],
        [stack.widthAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.widthAnchor]
    ]];

    UILabel *title = [self label:@"TrollCrosshair 1.2"];
    title.font = [UIFont systemFontOfSize:26 weight:UIFontWeightBold];
    [stack addArrangedSubview:title];
    self.status = [self label:@"尚未选择图片"];
    self.status.numberOfLines = 0;
    [stack addArrangedSubview:self.status];
    [stack addArrangedSubview:[self button:@"选择图片 / GIF" action:@selector(pickImage)]];

    self.previewCanvas = [UIView new];
    self.previewCanvas.backgroundColor = UIColor.secondarySystemBackgroundColor;
    self.previewCanvas.layer.cornerRadius = 12;
    self.previewCanvas.clipsToBounds = YES;
    self.previewCanvas.translatesAutoresizingMaskIntoConstraints = NO;
    [self.previewCanvas.heightAnchor constraintEqualToConstant:260].active = YES;
    [stack addArrangedSubview:self.previewCanvas];
    self.previewImageView = [UIImageView new];
    self.previewImageView.contentMode = UIViewContentModeScaleToFill;
    self.previewImageView.userInteractionEnabled = NO;
    self.previewImageView.translatesAutoresizingMaskIntoConstraints = YES;
    [self.previewCanvas addSubview:self.previewImageView];

    [self addSlider:@"X（水平位置）" min:-2048 max:2048 value:FISettings.shared.x toStack:stack];
    [self addSlider:@"Y（垂直位置）" min:-2048 max:2048 value:FISettings.shared.y toStack:stack];
    [self addSlider:@"缩放（25%–300%）" min:25 max:300 value:FISettings.shared.sizeScale toStack:stack];
    [self addSlider:@"透明度" min:0.05 max:1 value:FISettings.shared.alpha toStack:stack];

    self.toggleButton = [self button:@"开启悬浮" action:@selector(toggle)];
    self.toggleButton.titleLabel.font = [UIFont systemFontOfSize:18 weight:UIFontWeightSemibold];
    [stack addArrangedSubview:self.toggleButton];
    [stack addArrangedSubview:[self button:@"重置参数" action:@selector(resetValues)]];

    UILabel *note = [self label:@"跨 App 悬浮使用独立 HUD 进程与系统窗口托管。X / Y 调整位置，缩放统一调整图片大小，透明度调整显示效果。"];
    note.numberOfLines = 0;
    note.textColor = UIColor.secondaryLabelColor;
    [stack addArrangedSubview:note];
}

- (void)addSlider:(NSString *)name min:(float)min max:(float)max value:(float)value toStack:(UIStackView *)stack {
    UIStackView *row = [UIStackView new];
    row.axis = UILayoutConstraintAxisVertical;
    row.spacing = 4;
    [row addArrangedSubview:[self label:name]];
    UISlider *slider = [UISlider new];
    slider.minimumValue = min;
    slider.maximumValue = max;
    slider.value = value;
    [slider addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];
    [row addArrangedSubview:slider];
    [self.sliders addObject:slider];
    [stack addArrangedSubview:row];
}

- (void)pickImage {
    PHPickerConfiguration *config = [PHPickerConfiguration new];
    config.filter = PHPickerFilter.imagesFilter;
    config.selectionLimit = 1;
    PHPickerViewController *picker = [[PHPickerViewController alloc] initWithConfiguration:config];
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:nil];
}

- (NSURL *)applicationSupportURL {
    NSURL *dir = [NSFileManager.defaultManager URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject;
    [NSFileManager.defaultManager createDirectoryAtURL:dir withIntermediateDirectories:YES attributes:nil error:nil];
    return dir;
}

- (void)removePreviousImageFiles {
    NSURL *dir = [self applicationSupportURL];
    NSArray<NSURL *> *urls = [NSFileManager.defaultManager contentsOfDirectoryAtURL:dir includingPropertiesForKeys:nil options:NSDirectoryEnumerationSkipsHiddenFiles error:nil];
    NSSet *imageExtensions = [NSSet setWithArray:@[@"png", @"jpg", @"jpeg", @"gif", @"heic", @"webp", @"bmp", @"tif", @"tiff"]];
    for (NSURL *url in urls) {
        NSString *name = url.lastPathComponent;
        if (([name hasPrefix:@"TrollCrosshair."] || [name hasPrefix:@"FloatImage."]) && [imageExtensions containsObject:url.pathExtension.lowercaseString]) [NSFileManager.defaultManager removeItemAtURL:url error:nil];
    }
}

- (void)picker:(PHPickerViewController *)picker didFinishPicking:(NSArray<PHPickerResult *> *)results {
    [picker dismissViewControllerAnimated:YES completion:nil];
    NSItemProvider *provider = results.firstObject.itemProvider;
    if (!provider) return;

    NSString *gifType = [UTType typeWithFilenameExtension:@"gif"].identifier;
    BOOL isGIF = [provider hasItemConformingToTypeIdentifier:gifType];
    NSString *typeIdentifier = isGIF ? gifType : [UTType typeWithIdentifier:@"public.image"].identifier;
    __weak typeof(self) weakSelf = self;
    [provider loadFileRepresentationForTypeIdentifier:typeIdentifier completionHandler:^(NSURL *temporaryURL, NSError *error) {
        if (!temporaryURL || error) {
            [weakSelf loadImageDataFallbackFromProvider:provider];
            return;
        }
        NSString *ext = isGIF ? @"gif" : (temporaryURL.pathExtension.length ? temporaryURL.pathExtension : @"img");
        [weakSelf removePreviousImageFiles];
        NSURL *destination = [[weakSelf applicationSupportURL] URLByAppendingPathComponent:[@"TrollCrosshair" stringByAppendingPathExtension:ext]];
        NSError *copyError = nil;
        [[NSFileManager defaultManager] copyItemAtURL:temporaryURL toURL:destination error:&copyError];
        if (copyError) {
            dispatch_async(dispatch_get_main_queue(), ^{ weakSelf.status.text = [NSString stringWithFormat:@"图片保存失败：%@", copyError.localizedDescription]; });
            return;
        }
        [weakSelf adoptImageURL:destination];
    }];
}

- (void)loadImageDataFallbackFromProvider:(NSItemProvider *)provider {
    NSString *type = provider.registeredTypeIdentifiers.firstObject ?: [UTType typeWithIdentifier:@"public.image"].identifier;
    __weak typeof(self) weakSelf = self;
    [provider loadDataRepresentationForTypeIdentifier:type completionHandler:^(NSData *data, NSError *error) {
        if (!data || error) return;
        NSString *ext = [type.lowercaseString containsString:@"gif"] ? @"gif" : @"img";
        [weakSelf removePreviousImageFiles];
        NSURL *url = [[weakSelf applicationSupportURL] URLByAppendingPathComponent:[@"TrollCrosshair" stringByAppendingPathExtension:ext]];
        if (![data writeToURL:url options:NSDataWritingAtomic error:nil]) return;
        [weakSelf adoptImageURL:url];
    }];
}

- (void)adoptImageURL:(NSURL *)url {
    dispatch_async(dispatch_get_main_queue(), ^{
        UIImage *image = [FloatingController imageForURL:url];
        if (!image) { self.status.text = @"无法读取该图片格式"; return; }
        self.imageURL = url;
        self.previewImageView.image = image;
        self.status.text = [url.pathExtension.lowercaseString isEqualToString:@"gif"] ? @"已载入 GIF 动图" : @"已载入图片";
        [[FloatingController shared] showImageAtURL:url];
        [self updatePreview];
    });
}

- (void)loadSavedImage {
    NSURL *dir = [self applicationSupportURL];
    NSArray<NSURL *> *urls = [NSFileManager.defaultManager contentsOfDirectoryAtURL:dir includingPropertiesForKeys:nil options:NSDirectoryEnumerationSkipsHiddenFiles error:nil];
    NSURL *candidate = nil;
    NSSet *imageExtensions = [NSSet setWithArray:@[@"png", @"jpg", @"jpeg", @"gif", @"heic", @"webp", @"bmp", @"tif", @"tiff"]];
    for (NSURL *url in urls) {
        NSString *name = url.lastPathComponent;
        if (([name hasPrefix:@"TrollCrosshair."] || [name hasPrefix:@"FloatImage."]) && [imageExtensions containsObject:url.pathExtension.lowercaseString]) { candidate = url; break; }
    }
    if (candidate) [self adoptImageURL:candidate];
}

- (void)sliderChanged:(UISlider *)slider {
    NSUInteger i = [self.sliders indexOfObject:slider];
    FISettings *s = FISettings.shared;
    switch (i) {
        case 0: s.x = slider.value; break;
        case 1: s.y = slider.value; break;
        case 2: s.sizeScale = slider.value; break;
        case 3: s.alpha = slider.value; break;
    }
    [s save];
    [self updatePreview];
    [[FloatingController shared] refresh];
}

- (void)updatePreview {
    if (!self.previewImageView.image || !self.previewCanvas) return;
    FISettings *s = FISettings.shared;
    CGSize source = self.previewImageView.image.size;
    CGFloat longest = MAX(source.width, source.height);
    CGFloat scale = longest > 0 ? 180.0 / longest * (s.sizeScale / 100.0) : 1.0;
    CGFloat width = MAX(1, source.width * scale);
    CGFloat height = MAX(1, source.height * scale);
    self.previewImageView.bounds = CGRectMake(0, 0, width, height);
    self.previewImageView.center = CGPointMake(CGRectGetMidX(self.previewCanvas.bounds) + s.x * 0.12,
                                               CGRectGetMidY(self.previewCanvas.bounds) + s.y * 0.12);
    self.previewImageView.alpha = s.alpha;
}

- (void)syncControls {
    FISettings *s = FISettings.shared;
    NSArray *values = @[@(s.x), @(s.y), @(s.sizeScale), @(s.alpha)];
    for (NSUInteger i = 0; i < MIN(values.count, self.sliders.count); i++) self.sliders[i].value = [values[i] floatValue];
    [self updatePreview];
    [self updateToggleTitle];
}

- (void)updateToggleTitle {
    [self.toggleButton setTitle:(FISettings.shared.isEnabled ? @"关闭悬浮" : @"开启悬浮") forState:UIControlStateNormal];
}

- (void)toggle {
    if (!self.imageURL && !FISettings.shared.isEnabled) { self.status.text = @"请先选择一张图片或 GIF"; return; }
    [[FloatingController shared] setEnabled:!FISettings.shared.isEnabled];
    [self updateToggleTitle];
}

- (void)resetValues {
    [FISettings.shared reset];
    [self syncControls];
    [[FloatingController shared] refresh];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self updatePreview];
}
@end

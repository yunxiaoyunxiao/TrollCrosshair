#import <UIKit/UIKit.h>
@interface FloatingController : NSObject
+ (instancetype)shared;
+ (nullable UIImage *)imageForURL:(NSURL *)url;
- (void)showImageAtURL:(NSURL *)url;
- (void)refresh;
- (BOOL)setEnabled:(BOOL)enabled;
- (BOOL)performShortcutCommand:(NSString *)command;
- (NSString *)diagnosticLog;
@end
FOUNDATION_EXPORT int TCHUDMain(void);

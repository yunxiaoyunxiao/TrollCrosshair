#import <UIKit/UIKit.h>

@interface FloatingController : NSObject
+ (instancetype)shared;
+ (nullable UIImage *)imageForURL:(NSURL *)url;
- (void)showImageAtURL:(NSURL *)url;
- (void)refresh;
- (void)setEnabled:(BOOL)enabled;
- (BOOL)performShortcutCommand:(NSString *)command;
@end

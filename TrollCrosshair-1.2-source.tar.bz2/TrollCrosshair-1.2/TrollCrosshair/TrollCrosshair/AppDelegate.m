#import "AppDelegate.h"
#import "RootViewController.h"
#import "FISettings.h"
#import "FloatingController.h"

@implementation AppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.rootViewController = [RootViewController new];
    [self.window makeKeyAndVisible];
    return YES;
}

// Shortcuts can invoke trollcrosshair://toggle, trollcrosshair://show or trollcrosshair://hide (legacy floatimage:// URLs remain supported).
// iOS may bring the app to the foreground to deliver a custom URL; this is not
// a claim of background/system-level execution.
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url options:(NSDictionary<UIApplicationOpenURLOptionsKey,id> *)options {
    NSString *scheme = url.scheme.lowercaseString;
    if (![scheme isEqualToString:@"floatimage"] && ![scheme isEqualToString:@"trollcrosshair"]) return NO;
    NSString *action = url.host.lowercaseString ?: url.path.lowercaseString;
    if (![action isEqualToString:@"toggle"] &&
        ![action isEqualToString:@"show"] && ![action isEqualToString:@"on"] &&
        ![action isEqualToString:@"hide"] && ![action isEqualToString:@"off"]) return NO;
    return [[FloatingController shared] performShortcutCommand:action];
}
@end

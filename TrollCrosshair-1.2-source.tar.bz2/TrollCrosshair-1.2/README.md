# TrollCrosshair 1.2 (Build 6)

TrollCrosshair is an iOS/iPadOS image and GIF overlay utility for TrollStore testing on iOS 17 and later.

## Controls
- X / Y position, uniform scale (25%–300%), opacity, and one-tap reset.
- Image and GIF selection, saved-image restoration, and in-settings preview.
- A diagnostic-log button copies app and HUD process logs to the clipboard.

## Overlay process and diagnostics
- The main app starts a second instance of its executable in `-hud` mode.
- The helper logs bootstrap symbols, UIKit initialization, BackBoard hosting class/selector checks, registration invocation, process state, and notification setup.
- Enabling the overlay waits up to three seconds for a helper status handshake. A spawn failure, early exit, missing private API, registration exception, or timeout is reported as a failure instead of displaying a false success state.
- The helper writes `TrollCrosshair-HUD.status` and `TrollCrosshair-diagnostics.log` in the app's Application Support directory.
- Shortcuts currently open the app before executing the intent, avoiding background AppIntents helper-process communication failures.

BackBoard hosting uses private APIs and is OS-build dependent. A successful build and a successful registration invocation do not prove the overlay is visible over other apps. Verify on the target device and share the copied diagnostic log if it remains invisible.

## Build
GitHub Actions builds an ARM64 IPA and embeds the TrollStore entitlements using `ldid`. The workflow verifies the embedded entitlements and package integrity.

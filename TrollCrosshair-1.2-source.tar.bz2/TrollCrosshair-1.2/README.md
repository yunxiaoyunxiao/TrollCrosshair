# TrollCrosshair 1.2 (Build 4)

TrollCrosshair is an iOS/iPadOS image and GIF overlay utility intended for TrollStore testing on iOS 17 and later.

## Controls
- X / Y: move the floating image relative to the safe-area center.
- Scale: uniformly resize the image from 25% to 300%; there are no independent width/height controls.
- Opacity: adjust transparency.
- Reset: restore X, Y, scale and opacity together.
- GIF decoding, saved-image restoration, and an in-settings preview are retained.

## Overlay implementation
The app starts a second instance of its own executable in `-hud` mode. That helper initializes UIKit as a plugin process, creates a passthrough system-style window, and attempts to register its window context with `SBSAccessibilityWindowHostingController`. Settings and image data are shared through the app container; Darwin notifications refresh the helper window.

This is a private iOS implementation and must be validated on the target TrollStore/iOS build. A successful IPA build proves compilation and packaging, not that BackBoard hosting is accepted at runtime on every device or OS version. The UI should not report cross-app overlay success solely because the helper process spawned.

## Build
Use the GitHub Actions workflow `.github/workflows/build-test-ipa.yml` to create an unsigned IPA for TrollStore testing.

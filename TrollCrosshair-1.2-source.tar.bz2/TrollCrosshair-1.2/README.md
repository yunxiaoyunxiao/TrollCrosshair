# TrollCrosshair 1.2

Target: iOS/iPadOS 17.0+, TrollStore test environment.

## Native Shortcuts (ported from the previous TrollCrosshair implementation)

The app registers three native App Intents actions:

- **悬浮开关** — toggles the saved floating state.
- **开启悬浮** — enables the overlay, if an image has already been saved.
- **关闭悬浮** — disables the overlay.

All three intents set `openAppWhenRun = false`. They call `FloatingController.performShortcutCommand(_:)` directly rather than launching the app through a custom URL. The commands reuse the last image saved in the app's Application Support directory.

Legacy URL commands remain available:

- `trollcrosshair://toggle`
- `trollcrosshair://on` / `trollcrosshair://show`
- `trollcrosshair://off` / `trollcrosshair://hide`
- Legacy `floatimage://` scheme is retained for compatibility.

## Current limitation

The current `FloatingController` still uses an app-owned `UIWindow`. Native App Intents restore the previous background shortcut entry points, but this alone does **not** grant cross-app window hosting. The current build must not be described as having a verified system-wide overlay. The next engineering step is to port and validate the previous TrollCrosshair HUD-process/BackBoard hosting path against this version's image-file storage and X/Y/width/height/opacity settings.
